# [199] Binary Tree Right Side View

from typing import List, Optional
from collections import deque
from ds_types.tree import TreeNode

# Given the root of a binary tree, imagine yourself standing on the right side
# of it, return the values of the nodes you can see ordered from top to
# bottom.

# @lc code=start
class Solution:
    def rightSideView(self, root: Optional[TreeNode]) -> List[int]:

# @lc code=end
