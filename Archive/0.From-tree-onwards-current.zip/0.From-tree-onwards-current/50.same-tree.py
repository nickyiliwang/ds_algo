# @lc app=leetcode id=100 lang=python3

from typing import Optional
from ds_types.tree import TreeNode

# try it with a stack

# Input: p = [1,2,3], q = [1,2,3]
# Output: true

# try it with a stack

# @lc code=start
class Solution:
    def isSameTree(self, p: Optional[TreeNode], q: Optional[TreeNode]) -> bool:
        
# @lc code=end