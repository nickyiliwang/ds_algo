# @lc app=leetcode id=102 lang=python3

from typing import Optional, List
from collections import deque
from ds_types.tree import TreeNode

# Given the root of a binary tree, return the level order traversal of its
# nodes' values. (i.e., from left to right, level by level).

# @lc code=start
class Solution:
    def levelOrder(self, root: Optional[TreeNode]) -> List[List[int]]:

# @lc code=end
