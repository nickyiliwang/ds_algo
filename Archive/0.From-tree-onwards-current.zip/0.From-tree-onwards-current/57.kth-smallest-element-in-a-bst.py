# @lc app=leetcode id=230 lang=python3
from typing import Optional
from ds_types.tree import TreeNode
# Given the root of a binary search tree, and an integer k, return the kth smallest value (1-indexed) of all the values of the nodes in the tree.

# try with iterative

# @lc code=start
class Solution:
    def kthSmallest(self, root: Optional[TreeNode], k: int) -> int:

# @lc code=end
