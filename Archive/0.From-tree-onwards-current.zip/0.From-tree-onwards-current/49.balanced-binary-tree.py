# @lc app=leetcode id=110 lang=python3

from typing import Optional
from ds_types.tree import TreeNode


# @lc code=start
class Solution:
    def isBalanced(self, root: Optional[TreeNode]) -> bool:
        res = True

        def dfs(node):
            nonlocal res

            if not node:
                return 0

            left, right = dfs(node.left), dfs(node.right)

            if abs(left - right) > 1:
                res = False

            return 1 + max(left, right)

        dfs(root)

        return res


# @lc code=end
