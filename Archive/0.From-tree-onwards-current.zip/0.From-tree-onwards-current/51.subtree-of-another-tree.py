# @lc app=leetcode id=572 lang=python3

from typing import Optional
from ds_types.tree import TreeNode

# Given the roots of two binary trees p and q, write a function to check if they are the same or not.

# Two binary trees are considered the same if they are structurally identical, and the nodes have the same value.


# @lc code=start
class Solution:
    def isSubtree(self, root: Optional[TreeNode], subRoot: Optional[TreeNode]) -> bool:

# @lc code=end
