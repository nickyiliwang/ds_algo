from ds_types.tree import TreeNode
from typing import List, Optional

# @lc app=leetcode id=105 lang=python3

# @lc code=start
class Solution:
    def buildTree(self, preorder: List[int], inorder: List[int]) -> Optional[TreeNode]:

# @lc code=end
