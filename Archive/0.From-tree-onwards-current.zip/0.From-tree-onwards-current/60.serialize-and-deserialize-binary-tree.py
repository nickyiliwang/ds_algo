# @lc app=leetcode id=297 lang=python3
from ds_types.tree import TreeNode

# @lc code=start
class Codec:
    def serialize(self, root):

    def deserialize(self, data):

# @lc code=end
